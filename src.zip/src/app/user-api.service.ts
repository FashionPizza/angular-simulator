import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUser } from '../enums/User';

@Injectable({
  providedIn: 'root',
})
export class UserApiService {

  private http = inject(HttpClient);

  private readonly url = 'https://jsonplaceholder.typicode.com/users';

  getUsers(): Observable<IUser[]> {
    return this.http.get<IUser[]>(this.url);
  }

}
